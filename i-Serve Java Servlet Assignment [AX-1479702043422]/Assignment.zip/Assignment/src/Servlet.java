import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.*;
//import java.util.*;

/**
 * Servlet implementation class Servlet
 */
//WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private boolean made_request = false;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String line_break = "\r\n";
		Boolean has_name = request.getParameterMap().containsKey("name") && !request.getParameter("name").isEmpty();
		String the_name = request.getParameter("name");
		//response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(
			"<!DOCTYPE html>" + line_break +
			"    <html>" + line_break +
			"    <head>" + line_break +
			"    <meta charset=\"utf-8\" />" + line_break +
			"    <title>i-Servlet</title>" + line_break +
			"    <style type=\"text/css\">" + line_break +
			"        #form { border: solid 1px #c0c0c0; border-radius: 4px; box-sizing: border-box; width: 320px; margin: 10px auto; padding: 20px; }" + line_break +
			"        h1 { font-family: Arial, Tahoma, Verdana; font-size: 1.5em; text-align: center; }" + line_break +
			"        hr { border: none; background-color: #c0c0c0; height: 2px; }" + line_break +
			"    </style>" + line_break +
			"    </head>" + line_break +
			"    <body>" + line_break +
			"    <!-- Template by Jaycliff Arcilla -->" + line_break
		);
		if (has_name && !the_name.isEmpty()) {
			out.print("<h1>Hello " + the_name + "!</h1>");
			out.print("<hr />");
		} else {
			if (made_request) {
				out.print("<script type=\"text/javascript\">" + line_break);
				out.print("alert('You did not enter anything!');" + line_break);
				out.print("</script>" + line_break);
			}
		}
		out.print("<form id=\"form\" action=\"Servlet\" method=\"post\">");
		if (has_name && !the_name.isEmpty()) {
			out.print("<label for=\"text\">Enter Another Name:</label><br />");
		} else {
			out.print("<label for=\"text\">Enter Name:</label><br />");
		}
		out.print("<input name=\"name\" id=\"name\" type=\"text\" />");
		out.print("<input name=\"submit\" type=\"submit\" value=\"Submit\" />");
		out.print("</form>");
		out.print("</body>");
		out.print("</html>");
		made_request = false;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (!request.getParameter("name").isEmpty()) {
			try {
				//Class.forName("com.mysql.jdbc.Driver");
				//DriverManager.registerDriver(new com.mysql.jdbc.Driver());
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "assignment", "password");
				Statement statement = connection.createStatement();
				//ResultSet result_set = statement.executeQuery("SELECT * FROM assignment.users");
				int i = statement.executeUpdate("INSERT INTO assignment.users VALUES ('" + request.getParameter("name") + "')");
			} catch (Exception e) {
				System.out.println("CATCH: " + e);
			}
		}
		made_request = true;
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doHead(HttpServletRequest, HttpServletResponse)
	 */
	protected void doHead(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
/* PHP & JavaScript is so much easier :( */